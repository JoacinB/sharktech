<link rel="icon" type="image/vnd.microsoft.icon" href="favicon.ico">
<?php

include "verUsuarios.php"; // Using database connection file here
$ids = $_REQUEST['id'];
$alumno = $_REQUEST['alumno'];
$cialumno = $_REQUEST['cialumno'];
$grupo = $_REQUEST['grupo'];
$telefono = $_REQUEST['telefono'];

$update = ("UPDATE alumnos 
    SET
    alumno = '" .$alumno. "',
    cialumno = '" .$cialumno. "',
    grupo = '" .$grupo. "',
    telefono = '" .$telefono. "'

WHERE id='" .$ids. "'
");
$result_update = mysqli_query($conexion, $update);

echo "<script type='text/javascript'>
        window.location='verUsuarios.php';
    </script>";
    
?>