<link rel="icon" type="image/vnd.microsoft.icon" href="favicon.ico">
<?php

include "verMateriales.php"; // Using database connection file here
if (isset($_POST['update'],$_POST['id'])){
    $id=$_POST['id'];
    echo $id ;  
}
$nombres = $_REQUEST['nombre'];
$numserie = $_REQUEST['numserie'];
$estado = $_REQUEST['estado'];

$update = ("UPDATE materiales 
    SET
    nombre = '" .$nombres. "',
    numserie = '" .$numserie. "',
    estado = '" .$estado. "'

WHERE id='" .$id. "'
");
$result_update = mysqli_query($conexion, $update);

echo "<script type='text/javascript'>
        window.location='verMateriales.php';
    </script>";
    
?>