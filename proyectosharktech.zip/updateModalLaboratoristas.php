<link rel="icon" type="image/vnd.microsoft.icon" href="favicon.ico">
<?php

include "verLaboratoristas.php"; // Using database connection file here
$ids = $_REQUEST['id'];
$nombrelab = $_REQUEST['nombrelab'];
$cilab = $_REQUEST['cilab'];
$turno = $_REQUEST['turno'];
$fechain = $_REQUEST['fechain'];

$update = ("UPDATE laboratoristas 
    SET
    nombrelab = '" .$nombrelab. "',
    cilab = '" .$cilab. "',
    turno = '" .$turno. "',
    fechain = '" .$fechain. "'

WHERE id='" .$ids. "'
");
$result_update = mysqli_query($conexion, $update);

echo "<script type='text/javascript'>
        window.location='verLaboratoristas.php';
    </script>";
    
?>