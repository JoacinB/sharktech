<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Materiales</title>
    <link rel="stylesheet" href="css/materiales.css">
    <link rel="stylesheet" href="css/fonts.css" />
    


    
</head>
<link rel="icon" type="image/vnd.microsoft.icon" href="favicon.ico">



<body>
    <br><br>
    <form action="altasMateriales.php" method="post">
    <h4>Registro de recursos</h4>
        <p>Nombre del recurso</h1>
        <input type="text" name="nombre"><p>
        <p>Numero de serie (si existe)</h1>
        <input type="text" name="numserie"><p>
        <p>Estado</p>
        <select name="estado">
            <option value="Sano">Sano</option>
            <option value="Roto">Roto</option>
            <option value="Irreparable">Irreparable</option>
        </select>
        <br>
        <input type="submit" value="Enviar">
        <input type="submit" formaction="verMateriales.php" value="Ver recursos">
        <input type="submit" formaction="menu.php" value="Volver">
    </form>

</body>
