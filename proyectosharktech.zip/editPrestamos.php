

<!-- Modal -->
<div class="modal fade" id="exampleModalPrestamos<?php echo $prestamos['cialumno']; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalPrestamos" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalPrestamos">Editar</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form method="POST" action="updateModalPrestamos.php">
            <input type="hidden" name="cialumno" value="<?php echo $prestamos['cialumno'] ?>">
            <label for="recurso-name" class="col-form-label">Recurso:</label><br>
            <input type="text" name="recurso" value="<?php echo $prestamos['recurso'] ?>" placeholder="Recurso" Required><br>
            <label for="plazo-name" class="col-form-label">Plazo:</label><br>
            <input type="date" name="plazo" value="<?php echo $prestamos['plazo'] ?>" placeholder="Plazo" Required><br>
            <label for="fechadevo-name" class="col-form-label">Fecha de devolucion:</label><br>
            <input type="date" name="fechadevo" value="<?php echo $prestamos['fechadevo'] ?>" placeholder="Fecha devolución" Required><br><br>
            <button class="btn btn-primary" type="submit" name="update" value="Update">Guardar</button>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

        

