<link rel="icon" type="image/vnd.microsoft.icon" href="favicon.ico">

<!-- Modal -->
<div class="modal fade" id="exampleModalPrestamos<?php echo $prestamos['id']; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalPrestamos" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalPrestamos">Editar</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form method="POST" action="updateModalPrestamos.php" novalidate>
          <input type="hidden" name="id" value="<?php echo $prestamos['id'] ?>">
            <label for="cialumno-name" class="col-form-label">Cédula del alumno:</label><br>
            <input type="text" name="cialumno" value="<?php echo $prestamos['cialumno'] ?>" Required><br>
            <label for="recurso-name" class="col-form-label">Recurso:</label><br>
            <input type="text" name="recurso" value="<?php echo $prestamos['recurso'] ?>" Required><br>
            <label for="plazo-name" class="col-form-label">Plazo:</label><br>
            <input type="date" name="plazo" value="<?php echo $prestamos['plazo'] ?>" placeholder="Plazo" Required><br>
            <label for="fechadevo-name" class="col-form-label">Fecha de devolucion:</label><br>
            <input type="date" name="fechadevo" value="<?php echo $prestamos['fechadevo'] ?>" placeholder="Fecha devolución" Required><br><br>
            <button class="btn btn-primary" type="submit" name="update" value="Update">Guardar</button>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

        

