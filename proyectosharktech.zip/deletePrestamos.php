<?php

include "db.php"; // Conectar a la base de datos con include

$id = $_GET['id']; // Obtiene nombre mediante consulta

$del = mysqli_query($conexion,"delete from prestamos where id = '$id'"); // Borrar

if($del)
{
    mysqli_close($conexion); // Cierra conexion
    header("location:verPrestamos.php"); // redirecciona a la pagina de verMateriales
    exit;	
}
else
{
    echo "Error deleting record"; // si no se borra muestra error
}
?>