<?php

include "db.php"; // Conectar a la base de datos con include

$cialumno = $_GET['cialumno']; // Obtiene nombre mediante consulta

$del = mysqli_query($conexion,"delete from prestamos where cialumno = '$cialumno'"); // Borrar

if($del)
{
    mysqli_close($conexion); // Cierra conexion
    header("location:verPrestamos.php"); // redirecciona a la pagina de verMateriales
    exit;	
}
else
{
    echo "Error deleting record"; // si no se borra muestra error
}
?>