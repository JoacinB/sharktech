<html>
<head>
  <title>Usuarios</title>
</head>
<link rel="icon" type="image/vnd.microsoft.icon" href="favicon.ico" />
<body>
  <?php
  $conexion = mysqli_connect("localhost","u685508072_Administrador","Administrador1","u685508072_sharktech") or
    die("Problemas con la conexión");
  mysqli_query($conexion, "insert into alumnos(alumno,cialumno,grupo,telefono) values 
                       ('$_REQUEST[alumno]','$_REQUEST[cialumno]','$_REQUEST[grupo]','$_REQUEST[telefono]')")
    or die("Problemas en el select" . mysqli_error($conexion));
  mysqli_close($conexion);
  include("administrar.php");
  echo "El alumno fue dado de alta.";
  ?>
</body>
</html>
