<html>
<head>
  <title>Materiales</title>
</head>
<link rel="icon" type="image/vnd.microsoft.icon" href="favicon.ico" />
<body>
  <?php
  $conexion = mysqli_connect("localhost","u685508072_Administrador","Administrador1","u685508072_sharktech") or
    die("Problemas con la conexión");
  mysqli_query($conexion, "insert into materiales(nombre,numserie,estado) values 
                       ('$_REQUEST[nombre]','$_REQUEST[numserie]','$_REQUEST[estado]')")
    or die("Problemas en el select" . mysqli_error($conexion));
  mysqli_close($conexion);
  include("materiales.php");
  echo "El material fue dado de alta.";
  ?>
</body>
</html>
