<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KyZXEAg3QhqLMpG8r+8fhAXLRk2vvoC2f3B09zVXn8CA5QIVfZOJ3BCsw2P0p/We" crossorigin="anonymous">
<link rel="stylesheet" href="css/fonts.css" />
<body style='background-color:black'>

<?php 
$conexion = mysqli_connect("localhost","u685508072_Administrador","Administrador1","u685508072_sharktech") or
die("Problemas con la conexión");

 ?>


<!DOCTYPE html>
<html>
<head>
	<title>Ver Usuarios</title>
</head>
<link rel="icon" type="image/vnd.microsoft.icon" href="favicon.ico">
<body>



<nav class="navbar navbar-dark bg-dark">
  <div class="container-fluid">
    <form class="d-flex">
      <input class="form-control me-2" type="text" id="myInput" onkeyup="myFunction()" placeholder="Buscar" aria-label="Search">
      <button class="btn btn-outline-light" type="delete">X</button>
    </form>
    <button class="btn btn-outline-light" onclick="location.href='https://proyectoshark.tech/administrar.php'">Volver</button>
  </div>
</nav>
<br>


<div class="container">
  <div class="row">
    <div class="col">
    <table id="myTable" class="table table-dark table-hover table-striped">
  <thead>
		  <tr>
        <th scope="col">NOMBRE ALUMNO</th>
        <th scope="col">CÉDULA ALUMNO</th>
        <th scope="col">GRUPO</th>
        <th scope="col">TELÉFONO</th>
        <th scope="col">OPERACIONES</th>
	  	</tr>
    </thead>
		<?php 
		$sql="SELECT * from alumnos";
		$result=mysqli_query($conexion,$sql);

		while($alumnos=mysqli_fetch_array($result)){
		 ?>

		<tr>
            
      <td style="display:none;"><?php echo $alumnos['id'] ?></td>
            <td><?php echo $alumnos['alumno'] ?></td>
			<td><?php echo $alumnos['cialumno'] ?></td>
			<td><?php echo $alumnos['grupo'] ?></td>
			<td><?php echo $alumnos['telefono'] ?></td>
      <td>
      <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModalUsuarios<?php echo $alumnos['id']; ?>">Editar</button>
        <button class="btn btn-danger"><a href="deleteUsuarios.php?id=<?php echo $alumnos['id']; ?>" class="text-light text-decoration-none">Eliminar</a></button>
      </td>
		</tr>

    <?php include('editUsuarios.php'); ?>
	<?php 
	}
	 ?>
	</table>
  </div>
</div>
</div>




<script>
function myFunction() {
  // Declarar variables
  var input, filter, table, tr, td, i, txtValue;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable");
  tr = table.getElementsByTagName("tr");

  // Busca por toda la tabla y esconde las que no coinciden con la busqueda
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[1];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }
  }
}
</script>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-U1DAWAznBHeqEIlVSCgzq+c9gqGAJn5c/t99JyeKa9xxaYpSvHU5awsuZVVFIhvj" crossorigin="anonymous"></script>
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</body>
</html>