<html>
<head>
  <title>Laboratoristas</title>
</head>
<link rel="icon" type="image/vnd.microsoft.icon" href="favicon.ico" />
<body>
  <?php
  $conexion = mysqli_connect("localhost","u685508072_Administrador","Administrador1","u685508072_sharktech") or
    die("Problemas con la conexión");
  mysqli_query($conexion, "insert into laboratoristas(nombrelab,cilab,turno,fechain) values 
                       ('$_REQUEST[nombrelab]','$_REQUEST[cilab]','$_REQUEST[turno]','$_REQUEST[fechain]')")
    or die("Problemas en el select" . mysqli_error($conexion));
  mysqli_close($conexion);
  include("laboratoristas.php");
  echo "El laboratorista fue dado de alta.";
  ?>
</body>
</html>
