<link rel="icon" type="image/vnd.microsoft.icon" href="favicon.ico">

<!-- Modal -->
<div class="modal fade" id="exampleModalUsuarios<?php echo $alumnos['id']; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalUsuarios" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalUsuarios">Editar</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form method="POST" action="updateModalUsuarios.php" novalidate>
          <input type="hidden" name="id" value="<?php echo $alumnos['id'] ?>">
            <label for="alumno-name" class="col-form-label">Nombre del alumno:</label><br>
            <input type="text" name="alumno" value="<?php echo $alumnos['alumno'] ?>" Required><br>
            <label for="cialumno-name" class="col-form-label">Cédula del alumno:</label><br>
            <input type="text" name="cialumno" value="<?php echo $alumnos['cialumno'] ?>" Required><br>
            <label for="grupo-name" class="col-form-label">Grupo:</label><br>
            <input type="text" name="grupo" value="<?php echo $alumnos['grupo'] ?>" Required><br>
            <label for="telefono-name" class="col-form-label">Teléfono:</label><br>
            <input type="text" name="telefono" value="<?php echo $alumnos['telefono'] ?>" Required><br><br>
            <button class="btn btn-primary" type="submit" name="update" value="Update">Guardar</button>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

        

