<html>
<head>
  <title>Alta Préstamo</title>
</head>
<link rel="icon" type="image/vnd.microsoft.icon" href="favicon.ico" />
<body>
  <?php
  $plazo = date('Y-m-d', strtotime($_REQUEST['plazo']));
  $fechadevo = date('Y-m-d', strtotime($_REQUEST['fechadevo']));
  $conexion = mysqli_connect("localhost","u685508072_Administrador","Administrador1","u685508072_sharktech") or
    die("Problemas con la conexión");
  mysqli_query($conexion, "insert into prestamos(cialumno,recurso,plazo,fechadevo) values 
                       ('$_REQUEST[cialumno]','$_REQUEST[recurso]','$plazo','$fechadevo')")
    or die("Problemas en el select" . mysqli_error($conexion));
  mysqli_close($conexion);
  include("prestamos.php");
  echo "El préstamo fue dado de alta con éxito.";
  ?>
</body>
</html>
