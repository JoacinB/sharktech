<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Administrar</title>
    <link rel="stylesheet" href="css/administrar.css">
    <link rel="stylesheet" href="css/fonts.css" />
    


    
</head>
<link rel="icon" type="image/vnd.microsoft.icon" href="favicon.ico">



<body>
    <br><br>
    <form action="altasUsuarios.php" method="post">
    <h4>Registro de nuevos alumnos</h4>
        <p>Nombre del alumno *</h1>
        <input type="text" name="alumno"><p>
        <p>Cédula del alumno *</h1>
        <input type="text" name="cialumno"><p>
        <p>Grupo</h1>
        <input type="text" name="grupo"><p>
        <p>Teléfono</h1>
        <input type="text" name="telefono"><p>
        <br>
        <input type="submit" value="Enviar">
        <input type="submit" formaction="verUsuarios.php" value="Ver usuarios">
        <input type="submit" formaction="laboratoristas.php" value="Ir a laboratoristas">
        <input type="submit" formaction="menu.php" value="Volver">
    </form>

</body>
