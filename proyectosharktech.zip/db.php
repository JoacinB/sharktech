<?php

$conexion=mysqli_connect("localhost","u685508072_Administrador","Administrador1","u685508072_sharktech") 
?>


