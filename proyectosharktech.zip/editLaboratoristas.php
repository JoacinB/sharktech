<link rel="icon" type="image/vnd.microsoft.icon" href="favicon.ico">

<!-- Modal -->
<div class="modal fade" id="exampleModalLaboratoristas<?php echo $labo['id']; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLaboratoristas" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLaboratoristas">Editar</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form method="POST" action="updateModalLaboratoristas.php" novalidate>
          <input type="hidden" name="id" value="<?php echo $labo['id'] ?>">
            <label for="nombrelab-name" class="col-form-label">Nombre del laboratorista:</label><br>
            <input type="text" name="nombrelab" value="<?php echo $labo['nombrelab'] ?>" Required><br>
            <label for="cilab-name" class="col-form-label">Cédula del laboratorista:</label><br>
            <input type="text" name="cilab" value="<?php echo $labo['cilab'] ?>" Required><br>
            <label for="turno-name" class="col-form-label">Turno:</label><br>
            <select name="turno" value="<?php echo $labo['turno'] ?>" placeholder="Turno" Required><br><br>
            <option value="Matutino">Matutino</option>
            <option value="Vespertino">Vespertino</option>
            <option value="Nocturno">Nocturno</option>
          </select><br>
            <label for="fechain-name" class="col-form-label">Fecha de ingreso:</label><br>
            <input type="date" name="fechain" value="<?php echo $labo['fechain'] ?>" placeholder="Fecha ingreso" Required><br><br>
            <button class="btn btn-primary" type="submit" name="update" value="Update">Guardar</button>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

        

