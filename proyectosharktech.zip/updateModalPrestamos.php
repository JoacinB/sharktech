<link rel="icon" type="image/vnd.microsoft.icon" href="favicon.ico">
<?php

include "verPrestamos.php"; // Using database connection file here
$cialumno = $_REQUEST['cialumno'];
$recurso = $_REQUEST['recurso'];
$plazo = $_REQUEST['plazo'];
$fechadevo = $_REQUEST['fechadevo'];

$update = ("UPDATE prestamos 
    SET
    cialumno = '" .$cialumno. "',
    recurso = '" .$recurso. "',
    plazo = '" .$plazo. "',
    fechadevo = '" .$fechadevo. "'

WHERE cialumno='" .$cialumno. "'
");
$result_update = mysqli_query($conexion, $update);

echo "<script type='text/javascript'>
        window.location='verPrestamos.php';
    </script>";
    
?>