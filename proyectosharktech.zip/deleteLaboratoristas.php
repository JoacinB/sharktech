<link rel="icon" type="image/vnd.microsoft.icon" href="favicon.ico">
<?php

include "db.php"; // Conectar a la base de datos con include

$ids = $_GET['id']; // Obtiene nombre mediante consulta

$del = mysqli_query($conexion,"delete from laboratoristas where id = '$ids'"); // Borrar

if($del)
{
    mysqli_close($conexion); // Cierra conexion
    header("location:verLaboratoristas.php"); // redirecciona a la pagina de verMateriales
    exit;	
}
else
{
    echo "Error deleting record"; // si no se borra muestra error
}
?>