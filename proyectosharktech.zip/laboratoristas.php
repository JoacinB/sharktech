<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laboratoristas</title>
    <link rel="stylesheet" href="css/laboratoristas.css">
    <link rel="stylesheet" href="css/fonts.css" />
    


    
</head>
<link rel="icon" type="image/vnd.microsoft.icon" href="favicon.ico">



<body>
    <br><br>
    <form action="altasLaboratoristas.php" method="post">
    <h4>Registro de laboratorista</h4>
        <p>Nombre del laboratorista</h1>
        <input type="text" name="nombrelab"><p>
        <p>Cédula del laboratorista</h1>
        <input type="text" name="cilab"><p>
        <p>Turno</h1>
        <select name="turno">
            <option value="Matutino">Matutino</option>
            <option value="Vespertino">Vespertino</option>
            <option value="Nocturno">Nocturno</option>
        </select>
        <p>Fecha ingreso</h1>
        <input type="date" name="fechain"><p>
        <br>
        <input type="submit" value="Enviar">
        <input type="submit" formaction="verLaboratoristas.php" value="Ver laboratoristas">
        <input type="submit" formaction="administrar.php" value="Volver">
    </form>

</body>
