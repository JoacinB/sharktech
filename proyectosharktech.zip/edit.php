

<!-- Modal -->
<div class="modal fade" id="exampleModal<?php echo $mostrar['id']; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Editar</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form method="POST" action="updateModal.php" novalidate>
        <input type="hidden" name="id" value="<?php echo $mostrar['id'] ?>">
          <label for="recurso-name" class="col-form-label">Nombre:</label><br>
          <input type="text" name="nombre" value="<?php echo $mostrar['nombre'] ?>" Required><br>
          <label for="numserie-name" class="col-form-label">Numero de serie:</label><br>
          <input type="text" name="numserie" value="<?php echo $mostrar['numserie'] ?>" Required><br>
          <label for="estado-name" class="col-form-label">Estado:</label><br>
          <select name="estado" value="<?php echo $mostrar['estado'] ?>" placeholder="Estado" Required><br><br>
            <option value="Sano">Sano</option>
            <option value="Roto">Roto</option>
            <option value="Irreparable">Irreparable</option>
          </select>
          <button class="btn btn-primary" type="submit" name="update" value="Update">Guardar</button>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>


